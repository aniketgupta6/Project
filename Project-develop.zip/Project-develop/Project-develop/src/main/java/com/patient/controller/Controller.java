package com.patient.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.patient.dto.PatientDto;
import com.patient.service.PatientService;

@RestController
public class Controller {
	@Autowired
	private PatientService service;
	 
	@PostMapping(value="/patients")
	ResponseEntity<String>addPatient(@RequestBody PatientDto Dto){
		String message=service.addPatient(Dto);
		return new ResponseEntity<>(message,HttpStatus.CREATED);
	}
	//get all patient details
	@GetMapping(value="/patients")
	public ResponseEntity<List<PatientDto>> getAllPatient(){
		try {
			List<PatientDto> list=service.getAllPatient();
			return new ResponseEntity<List<PatientDto>>(list,HttpStatus.OK);
		}
		catch (Exception e) {
			return new ResponseEntity(null,HttpStatus.NO_CONTENT);			
		}
	}
	
	@GetMapping(value="/patients/{id}")
	public ResponseEntity<PatientDto>getSpecificPatient(@PathVariable Integer id){
		try {
			return new ResponseEntity<PatientDto>(service.getSpecificPatient(id),HttpStatus.OK);
		}catch (Exception e) {
			e.printStackTrace();
			return null;
			// TODO: handle exception
		}
	}
	
	@PutMapping(value="/patient/emailUpdate/{id}")
	public ResponseEntity<String>updatePatientEmail(@PathVariable Integer id,@RequestBody PatientDto patientDto){
		try {
			String message = service.updatePatientEmail(id, patientDto);
			return new ResponseEntity<String>(message, HttpStatus.ACCEPTED);
			
		}catch (Exception e) {
			e.toString();
			return new ResponseEntity<String>("Email ID not updated", HttpStatus.UNAUTHORIZED);
			// TODO: handle exception
		}
	}
	
	@PutMapping(value="/patients/phoneUpdate/{id}")
	public ResponseEntity<String> updatePatientPhoneNo(@PathVariable Integer id,@RequestBody PatientDto patientDto){
		try {
			return new ResponseEntity<String>(service.updatePatientMobileNo(id, patientDto),HttpStatus.ACCEPTED);
			
		}catch (Exception e) {
			return new ResponseEntity<String>("Phone number not updated" ,HttpStatus.UNAUTHORIZED);
		}
	}
	//delete by name and user&password
	@DeleteMapping(value="/patient/{name}/{upassword}")
	
	public ResponseEntity<String> PatientDeregistry(@PathVariable String name, @PathVariable String upassword){
		try {
			return new ResponseEntity<String>(service.PatientDeregistry(name, upassword),HttpStatus.ACCEPTED);
		}catch (Exception e) {
			return new ResponseEntity<String>("Not Successfully Deleted",HttpStatus.BAD_REQUEST);
			
		}
	}
}
