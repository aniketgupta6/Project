package com.patient.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="patient")
public class PatientEntity {

@Id
@GeneratedValue(strategy =GenerationType.AUTO)
@Column(name="patientId")
private Integer patientId;

@Column(name="patientName")
private String patientName;

@Column(name="User_Password")
private String uPassword;

@Column(name="age")
private int age;

@Column(name="phone_number")
private String phone_number;

@Column(name="emailId")
private String emailId;

@Column(name="diseases")
private String diseases;


public Integer getPatientId() {
	return patientId;
}

public void setPatientId(Integer patientId) {
	this.patientId = patientId;
}

public String getPatientName() {
	return patientName;
}

public void setPatientName(String patientName) {
	this.patientName = patientName;
}


public String getuPassword() {
	return uPassword;
}

public void setuPassword(String uPassword) {
	this.uPassword = uPassword;
}

public int getAge() {
	return age;
}

public void setAge(int age) {
	this.age = age;
}

public String getPhone_number() {
	return phone_number;
}

public void setPhone_number(String phone_number) {
	this.phone_number = phone_number;
}

public String getEmailId() {
	return emailId;
}

public void setEmailId(String emailId) {
	this.emailId = emailId;
}

public String getDiseases() {
	return diseases;
}

public void setDiseases(String diseases) {
	this.diseases = diseases;
}

}
