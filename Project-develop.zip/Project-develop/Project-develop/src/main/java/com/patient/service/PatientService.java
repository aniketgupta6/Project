package com.patient.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.patient.dto.PatientDto;
import com.patient.entity.PatientEntity;
import com.patient.repository.PatientRepo;


@Service
public class PatientService {
	@Autowired
	private PatientRepo prepo;
	
	public String addPatient(PatientDto Dto) {
		prepo.save(this.convertToEntity(Dto));
		return "!! Patient sucessfully Registered!" ;
		
	}
	
	public List<PatientDto> getAllPatient(){
		List<PatientEntity> listentity = prepo.findAll();
		List<PatientDto> listdto = new ArrayList<PatientDto>();
		for(PatientEntity e: listentity)
		{
			listdto.add(this.convertToDto(e));
		}
		return listdto;
	}
	
	public PatientDto getSpecificPatient(Integer id) {
		
		Optional<PatientEntity> obj1 = prepo.findById(id);
		
		if(obj1.isPresent()) {
			return this.convertToDto(obj1.get());
	}else {
		return null;
	}
		
	}
	
	public String PatientDeregistry(String name, String upassword) {
		PatientEntity object = new PatientEntity();
		object = prepo.findBynameAndPassword(name, upassword);
		if(object!=null) {
			prepo.delete(object);
			return "Patient Deregistered Successfully";
		}
		return "Patient Details not found";
	}
	
	public String updatePatientEmail(Integer id, PatientDto patientDto) {
		Optional<PatientEntity> obj = prepo.findById(id);
		PatientEntity obj1= null;
		if(obj!=null) {
			obj1 = new PatientEntity();
			obj1=obj.get();
			obj1.setEmailId(patientDto.getEmailId());
			prepo.save(obj1);
		
			return "Email Id Successfully updated!!";
		}
		return "There is some problem in updating emailId";
	}
	
	public String updatePatientMobileNo(Integer id, PatientDto patientDto) {
		Optional<PatientEntity> obj= prepo.findById(id);
		PatientEntity obj1= null;
		if(obj!=null) {
			obj1=obj.get();
			obj1.setPhone_number(patientDto.getPhone_number());
			prepo.save(obj1);
			return "phone number Successfully Updated !!";
			
		}
		return "There is some problem in updating phone number";
	}
	
	private PatientDto convertToDto(PatientEntity patientEntity) {
		PatientDto obj= new PatientDto();
		obj.setPatientId(patientEntity.getPatientId());
		obj.setEmailId(patientEntity.getEmailId());
		obj.setDiseases(patientEntity.getDiseases());
		obj.setAge(patientEntity.getAge());
		obj.setPhone_number(patientEntity.getPhone_number());
		obj.setPatientName(patientEntity.getPatientName());
		obj.setuPassword(patientEntity.getuPassword());
		return obj;
	}
	
	private PatientEntity convertToEntity(PatientDto patientDto) {
		PatientEntity obj = new PatientEntity();
		obj.setPatientId(patientDto.getPatientId());
		obj.setEmailId(patientDto.getEmailId());
		obj.setDiseases(patientDto.getDiseases());
		obj.setAge(patientDto.getAge());
		obj.setPhone_number(patientDto.getPhone_number());
		obj.setPatientName(patientDto.getPatientName());
		obj.setuPassword(patientDto.getuPassword());
		return obj;
	}
	
	@Override
	public String toString() {
		return "PatientService {patient=" + prepo + "}";
		
	}
	

}
