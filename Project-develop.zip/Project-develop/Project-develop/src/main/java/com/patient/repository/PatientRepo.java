package com.patient.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.patient.entity.PatientEntity;
@Repository
public interface PatientRepo extends JpaRepository<PatientEntity, Integer> {
	
	@Query(nativeQuery = true, value="SELECT * FROM OM_SAI_HOSPITAL.Patient P WHERE P.name =:name AND P.User_Password=:uPassword")
	PatientEntity findBynameAndPassword(@Param("name") String name,@Param("uPassword")String uPassword);

}
