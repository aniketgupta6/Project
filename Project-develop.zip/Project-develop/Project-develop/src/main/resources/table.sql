DROP DATABASE OM_SAI_HOSPITAL;
CREATE DATABASE OM_SAI_HOSPITAL;
use  OM_SAI_HOSPITAL;
CREATE TABLE patient(
patientId INT AUTO_INCREMENT  PRIMARY KEY,
patientName VARCHAR(250) NOT NULL,
User_Password VARCHAR(250),
age INT NOT NULL,
phone_number VARCHAR(10),
emailId VARCHAR(250),
diseases varchar(250) NOT NULL
);


INSERT INTO patient(patientName,User_Password,age,phone_number,emailId,diseases,patientId) VALUES
('rohit','Rohit123',23,'1234567890','rohitkr123@gmail.com','headpain',1),
('mohit','mohit213',13,'1234565646','mohitkr123@gmail.com','stomachpain',2),
('rahul','rahul@12',33,'3214565646','rahulkr123@gmail.com','legpain',3),
('vipul','vipul12',24,'8765565646','vipulkr123@gmail.com','moodswings',4),
('harsh','harsh12',24,'8766765646','harshkr123@gmail.com','mentaldisorder',5);

select * from patient;

